<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use App\Models\Wallet;
use App\Models\Currency;
use Illuminate\Http\Request;

class SignUpController extends Controller
{

	public function register(Request $request){
        
        
		$currency = Currency::first();

		$this->validate($request, [
            'email' => 'required|unique:users,email|email|max:255',
            'name'  =>  'required|unique:users,name|alpha_dash|min:5',
            'password'  =>  'required|min:6',
            'password_confirmation'	=>	'required|same:password',
            'terms' => 'required'
        ]);



        $user = User::create([
            'name'  => $request->name,
            'email' =>  $request->email,
            'password'  =>  bcrypt($request->password),
            'currency_id'	=>	 $currency->id
        ]);
        
        //Mail::send(new VerifyEmail($user));

        if ($user) {
        	wallet::create([
        		'user_id'	=> $user->id,
        		'amount'	=>	0,
        		'currency_id'	=> $currency->id
        	]);
        }

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            
            return redirect('/');
        }

        return redirect('/');
	}


}