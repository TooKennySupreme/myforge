<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use App\Models\Currency;
use App\Models\Exchange;
use App\Models\CurrencyExchangeRate;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Http\Request;

class ExchangeController extends Controller
{


    public function getExchangeRequestForm(Request $request, $currency_id = null, $second_currency_id = null ){
    	
    	$firstCurrenciesExchages = CurrencyExchangeRate::with('firstCurrency')->select('first_currency_id')->distinct()->get();

    	if (is_null($firstCurrenciesExchages)) {
    		dd('Please Contact admin to add currency exchange rates');
    	}

    	if (is_null($currency_id) or !($currency_id)) {
    		$firstCurrency = $firstCurrenciesExchages[0]->firstCurrency;
    	}else{
    		$firstCurrency = Currency::find($currency_id);
    	}


    	$secondCurrenciesExchanges = CurrencyExchangeRate::with('secondCurrency')->where('first_currency_id', $firstCurrency->id)->get();

        if (is_null($second_currency_id) or !($second_currency_id)) {
            $secondCurrency = $secondCurrenciesExchanges[0]->secondCurrency;
        }else{
            $secondCurrency = Currency::find($second_currency_id);
        }

        if ($firstCurrency->id == $secondCurrency->id) {
            return back();
        }

        Auth::user()->currency_id = $firstCurrency->id;
        Auth::user()->save();

        $wallet = Wallet::with('Currency')->where('user_id', Auth::user()->id)->where('currency_id',$secondCurrency->id)->first();

        $exchange = CurrencyExchangeRate::where('first_currency_id', $firstCurrency->id)->where('second_currency_id', $secondCurrency->id)->first();

        
        return view('exchange.exchangeRequestForm')
        ->with('wallet',$wallet)
        ->with('exchange', $exchange)
        ->with('secondCurrency',$secondCurrency)
        ->with('firstCurrency',$firstCurrency)
        ->with('secondCurrenciesExchanges',$secondCurrenciesExchanges)
        ->with('firstCurrenciesExchages',$firstCurrenciesExchages);
    }

    public function exchange(Request $request){

        $this->validate($request, [
            'amount'    =>  'required|numeric|between:1,'.Auth::user()->balance(),
            'exchange_id'   =>  'required|exists:currency_exchange_rates,id'
        ]);

        $currencyexchange = CurrencyExchangeRate::with('firstCurrency','secondCurrency')->find($request->exchange_id);

        $firstWallet = Wallet::where('currency_id', $currencyexchange->firstCurrency->id)->where('user_id', Auth::user()->id)->first();

        $secondWallet = Wallet::where('currency_id', $currencyexchange->secondCurrency->id)->where('user_id', Auth::user()->id)->first();

        $firstWallet->amount = $firstWallet->amount - ($request->amount);

        $secondWallet->amount = $secondWallet->amount + ( $request->amount * $currencyexchange->exchanges_to_second_currency_value );

        $firstWallet->save();
        $secondWallet->save();

        $exchange = Exchange::create([
            'user_id'   =>  Auth::user()->id,
            'first_currency_id' =>   $currencyexchange->firstCurrency->id,
            'second_currency_id'    =>  $currencyexchange->secondCurrency->id,
            'gross' =>  $request->amount,
            'fee'   =>  0.00,
            'net'   =>  $request->amount,

        ]);

        Auth::User()->RecentActivity()->save($exchange->Transactions()->create([
            'user_id' => Auth::User()->id,
            'entity_id'   =>  $exchange->id,
            'entity_name' =>   $currencyexchange->firstCurrency->name,
            'transaction_state_id'  =>  1, // waiting confirmation
            'money_flow'    => '-',
            'currency_id' =>  $currencyexchange->firstCurrency->id,
            'currency_symbol' =>  $currencyexchange->firstCurrency->symbol,
            'activity_title'    =>  'Currency Exchange',
            'gross' =>  $exchange->gross,
            'fee'   =>  $exchange->fee,
            'net'   =>  $exchange->net,
            'balance'   =>  $firstWallet->amount
        ]));

        Auth::User()->RecentActivity()->save($exchange->Transactions()->create([
            'user_id' => Auth::User()->id,
            'entity_id'   =>  $exchange->id,
            'entity_name' =>   $currencyexchange->secondCurrency->name,
            'transaction_state_id'  =>  1, // waiting confirmation
            'money_flow'    => '+',
            'currency_id' =>  $currencyexchange->secondCurrency->id,
            'currency_symbol' =>  $currencyexchange->secondCurrency->symbol,
            'activity_title'    =>  'Currency Exchange',
            'gross' =>  $request->amount * $currencyexchange->exchanges_to_second_currency_value,
            'fee'   =>  $exchange->fee,
            'net'   =>  $request->amount * $currencyexchange->exchanges_to_second_currency_value,
            'balance'   =>  $secondWallet->amount
        ]));

        return redirect('home');


    }
}
