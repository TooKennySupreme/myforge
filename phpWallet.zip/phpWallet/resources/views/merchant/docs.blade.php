@extends('layouts.app')

@section('content')
@include('partials.nav')
<div class="row">
	   @include('partials.sidebar')
	   <div class="col-md-9 " style="padding-right: 0">
	   
	   	<div class="clearfix"></div>
		<h3>The Merchant API integration consists in the steps below.</h3>
		<h5><strong>Step 1:</strong></h5>
	   	<div class="alert alert-info mb-5">
	   		<p>Send a CURL POST request that contains <strong>'merchant_key'</strong>, <strong>'invoice'</strong>, and <strong>'currency_code'</strong> variables to  <kbd>{{url('/')}}/purchase/link</kbd>
	   		</p> 
	   		<p class="">Then phpWallet will send back a response containing a link to your website.
	   		</p>
	   		<p class="">The <strong>'invoice'</strong> variable must be in a JSON format and must follow a structure shown below:
	   		</p>
	   		<p class="mb-0 ">
	   			<pre class="mb-0  p-5 br-2">$invoice['items'] = array(
    array(
        'name' => 'Product 1',
        'price' => (float)20.000,
        'desciption'    =>  'Product 1 description',
        'qty' => 1
    ),
    array(
        'name' => 'Product 2',
        'price' => (float)10.00,
        'desciption'    =>  'Product 2 description',
        'qty' => 1
    ),
    array(
        'name' => 'Product 3',
        'price' => (float)10.00,
        'desciption'    =>  'Product 3 description',
        'qty' => 1
    )
);

$invoice['invoice_id'] = rand(1,50); // should be the same invoice id as the one in your store database
$invoice['invoice_description'] = "Order with Invoice ".  $invoice['invoice_id'] ;
$invoice['total'] = 40.00;
$invoice['return_url'] = url('pay/success/?');
$invoice['cancel_url'] = url('pay/cancel');

$invoice = json_encode($invoice);
	   			</pre>
	   		</p>
	   	</div>
	   	<div>
<pre class="mb-0 bg-dark text-white  p-5 br-2">
	$post = array(
        'merchant_key'=> '{{$merchant->merchant_key}}',
        'invoice'=> $invoice,
        'currency_code' =>  '{{$merchant->currency->code}}'
        );

        

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, '{{url('/')}}/purchase/link' );
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

        $response = json_decode(curl_exec($ch),true);

        curl_close($ch);
	   		</pre>
	   	</div>
	   	<h5 class="mt-5"><strong>Step 2:</strong></h5>
	   	<div class="alert alert-info mb-5">
	   		<p class="mb-0">Once you’ve got the response with the link in your website,  redirect your user to the received link. The user will be asked to log in and pay the invoice. 
	   		</p>

	   	</div>
	   	<div>
<pre class="mb-0 bg-dark text-white  p-5 br-2">
        // var_dump($response);

        if ($response['status'] == true) {
           //if response status is true, that means we have a link and we redirect the user to {{setting('site.site_name')}}
           header('Location: '.$response['link'].'');
        }else{
            var_dump($response);
        }
	   		</pre>
	   	</div>
	   	<h5 class="mt-5"><strong>Step 3:</strong></h5>
	   	<div class="alert alert-info mb-5">
	   		<p class="mb-0"> When the user pays the invoice, he's redirected back to the URL specified in $invoice['return_url'] with a token as a query string.<br> Then in your website, use that token to make another CURL POST request to phpWallet to check if the token is valid or not. by comparing the merchant id from the token and your merchant id.</br> You can even check if the invoice from the token is the same as the invoice from your website.	   			
	   		</p>
	   	</div>
	   		   	<div>
<pre class="mb-0 bg-dark text-white  p-5 br-2">
        
        if (isset($_GET['token']) and !is_null($_GET['token'])) {
        
            $post = array(
            'merchant_key'=> '{{$merchant->merchant_key}}',
            'token'=> $_GET['token']
            );


            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, '{{url('/')}}/request/status' );
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

            //var_dump(curl_exec($ch));
            $response = json_decode(curl_exec($ch),true);

            curl_close($ch);

            // var_dump($response);

            if ($response['status'] == true) {

                if ($response['data']['entity_id'] == $this->phpWallet_merchant_id) {
                   
					// Handle your websites code here
                }else{
                    dd('invalid_merchant_id');
                }
            }else{
                var_dump($response);
            }
        }
	   		</pre>
	   	</div>
	   	{{--
	   	<table class="table table-striped">
	   		<thead class="bg-primary text-center text-white">
				<tr>
				  	<th>Key</th>
				  	<th>Value</th>
				</tr>
			</thead>
	   		 <tbody>
	   		 	@foreach($merchantArray as $key => $value)
	   		 	<tr>
	   		 		<td scope="row"><strong>{{$key}}</strong></td>
	   		 		<td scope="row" class=" bg-dark text-white border-info">{{$value}}</td>
	   		 	</tr>
	   		 	@endforeach
	   		 </tbody>
	   	</table>
	   	--}}
	   	
	   </div>
</div>
@endsection

@section('footer')
	@include('partials.footer')
@endsection