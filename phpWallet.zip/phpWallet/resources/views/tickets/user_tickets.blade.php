@extends('layouts.app')

@section('content')
@include('partials.nav')
    <div class="row">
        @include('partials.sidebar')
        <div class="col-md-9">
            <h4 class="bold">{{__('My Tickets')}}</h4>
            <div class="row">
              <div class="col">
                <a href="{{url('/')}}/new_ticket" class="btn btn-outline-primary float-right mb-4">{{__('Add New')}}</a>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="panel panel-default">
                <div class="panel-body">
                    @if ($tickets->isEmpty())
                        <p>{{__('You have not created any tickets.')}}</p>
                    @else
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>{{__('Category')}}</th>
                                    <th>{{__('Title')}}</th>
                                    <th>{{__('Status')}}</th>
                                    <th>{{__('Last Updated')}}</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach ($tickets as $ticket)
                                <tr>
                                    <td>
                                    @foreach ($categories as $category)
                                            {{ $category->name }}
                                    @endforeach
                                    </td>
                                    <td>
                                        <a href="{{ url('tickets/'. $ticket->ticket_id) }}">
                                            #{{ $ticket->ticket_id }} - {{ $ticket->title }}
                                        </a>
                                    </td>
                                    <td>
                                    @if ($ticket->status === 'Open')
                                        <span class="label label-success">{{ $ticket->status }}</span>
                                    @else
                                        <span class="label label-danger">{{ $ticket->status }}</span>
                                    @endif
                                    </td>
                                    <td>{{ $ticket->updated_at }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {{ $tickets->render() }}
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection