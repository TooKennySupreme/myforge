@extends('layouts.app')

@section('content')
@include('partials.nav')
    <div class="row">
        @include('partials.sidebar')
		
		<div class="col-md-9 " style="padding-right: 0">
        
	        @if($deposits->total()>0)
  <div class="card border-light">
      <div class="card-header bg-light">
        <h4>{{__('My Deposits')}}</h4>
      </div>
      <div class="card-body">
          <table class="table table-striped"  style="margin-bottom: 0;">
            <thead>
              <tr>
                <th>{{__('Date')}}</th>
                <th>{{__('Method')}}</th>
                <th>{{__('Gross')}}</th>
                <th>{{__('Fee')}}</th>
                <th>{{__('Net')}}</th>
                
              </tr>
            </thead>
            <tbody>
              @forelse($deposits as $deposit)
				<tr>
              	 	<td>{{$deposit->created_at->format('d M Y')}} <br> @include ('deposits.partials.status')</td>
              	 	<td>{{$deposit->Method->name}}</td>
              		<td>{{$deposit->gross()}}</td>
                	<td>{{$deposit->fee()}}</td>
                	<td>{{$deposit->net()}}</td>
              	</tr>
              @empty
              
              @endforelse
          </tbody>
          </table>
      </div>
      @if($deposits->LastPage() != 1)
        <div class="card-footer">
            {{$deposits->links()}}
        </div>
      @else
      @endif
  </div>
@endif

    	</div>

    </div>

@endsection

@section('footer')
  @include('partials.footer')
@endsection