<?php
symlink('/home/scrizrea/pagador.scriptdemo.website/storage/app/public', '/home/scrizrea/pagador.scriptdemo.website/public/storage');
?>